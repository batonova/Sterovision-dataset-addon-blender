The "images" folder contains images from the camera, the "depth map" contains depth maps, 
and the text file contains line-by-line information about each entry, including image 
names, camera settings and its position, and coordinates of all vertices of all figures 
of the scene, if this option was selected.